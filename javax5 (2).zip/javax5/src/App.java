public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Welcome to Java\nWelcome to Java\nWelcome to Java\nWelcome to Java\nWelcome to Java");
    }
}
